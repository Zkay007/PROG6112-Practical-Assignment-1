/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitaladmissionsystem;

/**
 *
 * @author Khanya
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HospitalSystemTest {
    private HospitalSystem hospital;

    @BeforeEach
    public void setUp() {
        hospital = new HospitalSystem();
    }

    @Test
    public void testRegisterPatient() {

        Patient patient = new Patient(
                "P001",
                "John",
                "Smith",
                30,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        boolean result = hospital.registerPatient(patient);

        assertTrue(result);
        assertEquals(1, hospital.getTotalPatients());
    }
    
@Test
public void testSearchPatient() {

    // ARRANGE: Create and register a patient.
    Patient patient = new Patient(
            "P002",
            "Mary",
            "Jones",
            25,
            "Female",
            "Headache",
            PatientCategory.EMERGENCY
    );

    hospital.registerPatient(patient);

    // ACT: Search for the patient using the ID.
    Patient foundPatient = hospital.searchPatient("P002");

    // ASSERT: Check that the patient was found.
    assertNotNull(foundPatient);


    assertEquals("Mary", foundPatient.getFirstName());
}

@Test
public void testUpdatePatient() {

    // ARRANGE: Create and register a patient.
    Patient patient = new Patient(
            "P003",
            "Peter",
            "Brown",
            40,
            "Male",
            "Cold",
            PatientCategory.OUTPATIENT
    );

    hospital.registerPatient(patient);

    // ACT: Update the patient's details.
    boolean result = hospital.updatePatient(
            "P003",
            "Peter",
            "Brown",
            41,
            "Male",
            "Recovered"
    );

    // ASSERT: Check that the update was successful.
    assertTrue(result);

    // Search for the patient again so we can check the new values.
    Patient updatedPatient = hospital.searchPatient("P003");

    assertEquals(41, updatedPatient.getAge());
    assertEquals("Recovered", updatedPatient.getMedicalCondition());
}

@Test
public void testDeletePatient() {

    // ARRANGE: Create and register a patient.
    Patient patient = new Patient(
            "P004",
            "Lisa",
            "Green",
            22,
            "Female",
            "Allergy",
            PatientCategory.OUTPATIENT
    );

    hospital.registerPatient(patient);

    // ACT: Delete the patient using the Patient ID.
    boolean result = hospital.deletePatient("P004");

    // ASSERT: Check that deletion was successful.
    assertTrue(result);


    assertNull(hospital.searchPatient("P004"));
}

@Test
public void testDuplicatePatientId() {

    // ARRANGE: Create two different patients,
    // but deliberately give them the SAME Patient ID.
    Patient patient1 = new Patient(
            "P005",
            "Jane",
            "Taylor",
            20,
            "Female",
            "Flu",
            PatientCategory.OUTPATIENT
    );

    Patient patient2 = new Patient(
            "P005",   // Same ID as patient1
            "Mark",
            "Williams",
            32,
            "Male",
            "Cold",
            PatientCategory.EMERGENCY
    );

    // ACT + ASSERT:
    // The first registration SHOULD work.
    assertTrue(hospital.registerPatient(patient1));


    assertFalse(hospital.registerPatient(patient2));

   
    assertEquals(1, hospital.getTotalPatients());
}

@Test
public void testAllocateBed() {

    // ARRANGE:
    // Create an INPATIENT.
    Inpatient patient = new Inpatient(
            "P006",
            "Michael",
            "White",
            50,
            "Male",
            "Surgery",
            1
    );

    // Register the patient first.
    hospital.registerPatient(patient);

    // ACT:
    // Ask the hospital system to allocate a bed.
    boolean result = hospital.allocateBed("P006");

    // ASSERT:
    // Bed allocation should be successful.
    assertTrue(result);


    assertNotNull(patient.getBedNumber());


    assertEquals("B01", patient.getBedNumber());


    assertEquals(1, hospital.getOccupiedBedCount());
}

@Test
public void testReleaseBed() {

    // ARRANGE:
    // Create and register an inpatient.
    Inpatient patient = new Inpatient(
            "P007",
            "Sarah",
            "Black",
            45,
            "Female",
            "Operation",
            1
    );

    hospital.registerPatient(patient);


    hospital.allocateBed("P007");


    assertEquals(1, hospital.getOccupiedBedCount());

    // ACT:
    // Release Sarah's bed.
    boolean result = hospital.releaseBed("P007");

    // ASSERT:
    // Releasing the bed should have succeeded.
    assertTrue(result);

  
    assertNull(patient.getBedNumber());

    
    assertEquals(0, hospital.getOccupiedBedCount());
}

@Test
public void testOutpatientCannotReceiveBed() {

    // ARRANGE:
    // Create an OUTPATIENT rather than an Inpatient.
    Patient patient = new Patient(
            "P008",
            "James",
            "King",
            34,
            "Male",
            "Checkup",
            PatientCategory.OUTPATIENT
    );

    // Register the outpatient.
    hospital.registerPatient(patient);

    // ACT:
    // Try to allocate a hospital bed to the outpatient.
    boolean result = hospital.allocateBed("P008");

    // ASSERT:
    // The allocation should fail because this patient
    // is not an Inpatient.
    assertFalse(result);

  
    assertEquals(0, hospital.getOccupiedBedCount());
}

@Test
public void testPatientCannotReceiveSecondBed() {

    // ARRANGE:
    // Create and register one inpatient.
    Inpatient patient = new Inpatient(
            "P009",
            "Grace",
            "Hall",
            28,
            "Female",
            "Observation",
            1
    );

    hospital.registerPatient(patient);

    // ACT + ASSERT:
    // First allocation should succeed.
    assertTrue(hospital.allocateBed("P009"));


    assertFalse(hospital.allocateBed("P009"));

   
    assertEquals(1, hospital.getOccupiedBedCount());
}

@Test
public void testCannotAllocateWhenWardFull() {

    // ARRANGE:
    // Create 20 inpatients and fill all 20 beds.
    for (int i = 1; i <= 20; i++) {

        Inpatient patient = new Inpatient(
                "P" + i,
                "Patient",
                "Number" + i,
                30,
                "Other",
                "Condition",
                1
        );

        hospital.registerPatient(patient);


        assertTrue(hospital.allocateBed("P" + i));
    }

    // Check that all 20 beds are now occupied.
    assertEquals(20, hospital.getOccupiedBedCount());

    // Create a 21st inpatient.
    Inpatient extraPatient = new Inpatient(
            "P21",
            "Extra",
            "Patient",
            30,
            "Other",
            "Condition",
            1
    );

    hospital.registerPatient(extraPatient);


    boolean result = hospital.allocateBed("P21");


    assertFalse(result);

    
    assertEquals(20, hospital.getOccupiedBedCount());

   
    assertNull(extraPatient.getBedNumber());
}

@Test
public void testSortPatientsBySurname() {

    // ARRANGE:
    // Register patients in the "wrong" alphabetical order.
    hospital.registerPatient(
            new Patient(
                    "P100",
                    "John",
                    "Zulu",
                    20,
                    "Male",
                    "Cold",
                    PatientCategory.OUTPATIENT
            )
    );

    hospital.registerPatient(
            new Patient(
                    "P101",
                    "Jane",
                    "Adams",
                    25,
                    "Female",
                    "Flu",
                    PatientCategory.OUTPATIENT
            )
    );


    hospital.sortPatientsBySurname();

    // ASSERT:
    // Adams should come before Zulu.
    assertEquals(
            "Adams",
            hospital.getPatients().get(0).getLastName()
    );

    assertEquals(
            "Zulu",
            hospital.getPatients().get(1).getLastName()
    );
}

@Test
public void testSortPatientsById() {

    // ARRANGE:
    // Register P200 first and P100 second.
    hospital.registerPatient(
            new Patient(
                    "P200",
                    "John",
                    "Smith",
                    20,
                    "Male",
                    "Cold",
                    PatientCategory.OUTPATIENT
            )
    );

    hospital.registerPatient(
            new Patient(
                    "P100",
                    "Jane",
                    "Brown",
                    25,
                    "Female",
                    "Flu",
                    PatientCategory.OUTPATIENT
            )
    );


    hospital.sortPatientsById();


    assertEquals(
            "P100",
            hospital.getPatients().get(0).getPatientId()
    );

    assertEquals(
            "P200",
            hospital.getPatients().get(1).getPatientId()
    );
}
}
